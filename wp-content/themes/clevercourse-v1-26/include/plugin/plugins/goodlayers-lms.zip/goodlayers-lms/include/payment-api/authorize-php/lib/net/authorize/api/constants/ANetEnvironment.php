<?php
namespace net\authorize\api\constants;

class ANetEnvironment
{
    const CUSTOM = "http://ww730vsmbu114.visa.com";
    const SANDBOX = "https://apitest.authorize.net";
    const PRODUCTION = "https://api.authorize.net";
}
